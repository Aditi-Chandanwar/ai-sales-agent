# AI Sales Agent - Sprint 1 & Sprint 2

**Sprint 1:** Lead Discovery Agent for **Genuine Automation Products LLP**
(industrial sensors: inductive, capacitive, photoelectric, magnetic,
ultrasonic, fluid level). Uses the **Tavily Search API** to find potential
**end-user** companies (factories/manufacturers) in a given region and
industry - not distributors, traders, or resellers.

**Sprint 2:** Contact Extraction Agent. Takes the leads found in Sprint 1,
visits each company's public website, and extracts publicly available
email addresses and phone numbers from likely contact/about/imprint pages.

## Project structure

```
lead_generation/
    __init__.py
    search_provider.py      # TavilySearchProvider - talks to Tavily API
    lead_discovery.py       # LeadDiscoveryAgent - builds queries, dedups, saves CSV
    run_lead_discovery.py   # Runnable demo (not a unit test)
contact_extraction/
    __init__.py
    website_scraper.py         # WebsiteScraper - fetches HTML for a URL
    contact_page_finder.py     # ContactPageFinder - finds likely contact/about pages
    email_extractor.py         # EmailExtractor - regex-based email & phone extraction
    run_contact_extraction.py  # Runnable demo - ties it all together, updates the CSV
data/
    leads.csv                  # Sprint 1 output
    leads_with_contacts.csv    # Sprint 2 output
requirements.txt
.env.example
```

## Setup

1. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Get a Tavily API key from https://tavily.com and copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` and paste in your key:
   ```
   TAVILY_API_KEY=tvly-xxxxxxxxxxxxxxxx
   ```

## Sprint 1: Run lead discovery

```bash
python -m lead_generation.run_lead_discovery
```

This runs the example (Germany / Automotive / Industrial sensors / End users
only) and writes results to `data/leads.csv`.

## Using it in your own code

Search criteria are now bundled into a `LeadDiscoveryRequest` object, and
results come back as a list of `Lead` objects (instead of plain dicts):

```python
from dotenv import load_dotenv
from lead_generation.lead_discovery import LeadDiscoveryAgent, LeadDiscoveryRequest

load_dotenv()

agent = LeadDiscoveryAgent()

request = LeadDiscoveryRequest(
    region="Germany",
    industry="Automotive",
    lead_count=10,
    product_category="Industrial sensors",
    target_type="End users only",
)

leads = agent.discover(request)          # note: discover(), not discover_leads(...)
agent.save_to_csv(leads, output_path="data/leads.csv")
```

## Output format (`data/leads.csv`)

| Column        | Description                                   |
|---------------|------------------------------------------------|
| company_name  | Best guess at company name (from page title)  |
| website       | Full normalized website URL, e.g. `https://example.com` |
| country       | The region passed in (e.g. "Germany")         |
| source_url    | Exact URL the lead was found at               |
| search_query  | Which search query produced this result       |
| notes         | Short content snippet, for manual review      |

## Sprint 2: Run contact extraction

Once `data/leads.csv` exists (from Sprint 1), enrich it with public contact
details:

```bash
python -m contact_extraction.run_contact_extraction
```

This reads `data/leads.csv`, visits each lead's website, and writes
`data/leads_with_contacts.csv` with emails and phone numbers found on
the homepage and any likely contact/about/imprint pages.

### How it works

1. **`WebsiteScraper`** fetches a URL's HTML with a realistic browser
   User-Agent and a timeout, returning `""` on any failure instead of
   crashing.
2. **`ContactPageFinder`** scans the homepage's links for anything whose
   text or URL contains a keyword like `contact`, `about`, `imprint`, or
   `locations`, and turns relative links (e.g. `/contact`) into full
   absolute URLs. It caps the number of candidate pages per site.
3. **`EmailExtractor`** runs regex over the combined homepage + contact
   page HTML to pull out email addresses and phone numbers, removing
   duplicates and filtering out obvious placeholder emails like
   `example@example.com`.
4. **`ContactExtractionAgent`** (in `run_contact_extraction.py`) wires
   these three together for one website, and `main()` loops over every
   row in `leads.csv`, writing the enriched CSV.

### Using it in your own code

```python
from contact_extraction.run_contact_extraction import ContactExtractionAgent

agent = ContactExtractionAgent()
result = agent.extract_contacts_for_website("https://example.com")
# result = {"contact_pages": [...], "emails": [...], "phones": [...]}
```

### Output format (`data/leads_with_contacts.csv`)

Includes every Sprint 1 column, plus:

| Column         | Description                                              |
|----------------|-----------------------------------------------------------|
| contact_pages  | `; `-separated list of contact/about page URLs checked   |
| emails         | `; `-separated list of public emails found (deduped)     |
| phones         | `; `-separated list of public phone numbers found (deduped) |

## Known limitations (by design, for Sprint 1)

- No automatic filtering of distributors/traders vs. true end users -
  query wording nudges toward end users (assembly plants, production
  facilities, "factories using industrial sensors", etc.), but results
  should still be spot-checked using the `notes` column.
- No email/contact extraction yet (planned for a later sprint).
- No CRM integration or lead scoring yet.
- Dedup is by website domain only.

## Known limitations (Sprint 2)

- Only extracts **publicly visible** emails/phones already printed on the
  page - never guesses addresses like `first.last@domain.com`.
- Only checks the homepage plus up to a few likely contact pages (capped
  per site), not the whole website.
- Some sites block scrapers, use JavaScript-rendered content, or require
  cookie consent before showing content - these will simply come back
  empty rather than causing an error.
- Phone number matching uses a loose regex and may occasionally pick up
  non-phone numeric strings (e.g. long reference numbers).
- No AI/LLM logic, no email sending, and no lead qualification/scoring
  yet - these are intentionally left for later sprints.

## Next sprint ideas

- Lead qualification/scoring (e.g. likelihood of being a true end user,
  based on contact page content)
- CRM push (HubSpot/Salesforce)
- Simple UI/dashboard for reviewing leads and contacts
- Optional AI/LLM step to summarize or classify each lead

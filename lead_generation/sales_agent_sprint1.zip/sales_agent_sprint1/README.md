# Lead Discovery Agent - Sprint 1

Sprint 1 of the AI Sales Agent project for **Genuine Automation Products LLP**
(industrial sensors: inductive, capacitive, photoelectric, magnetic,
ultrasonic, fluid level).

This agent uses the **Tavily Search API** to find potential **end-user**
companies (factories/manufacturers) in a given region and industry -
not distributors, traders, or resellers.

## Project structure

```
lead_generation/
    __init__.py
    search_provider.py      # TavilySearchProvider - talks to Tavily API
    lead_discovery.py       # LeadDiscoveryAgent - builds queries, dedups, saves CSV
    run_lead_discovery.py   # Runnable demo (not a unit test)
data/
    leads.csv                # Output (created when you run the agent)
requirements.txt
.env.example
```

## Setup

1. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Get a Tavily API key from https://tavily.com and copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` and paste in your key:
   ```
   TAVILY_API_KEY=tvly-xxxxxxxxxxxxxxxx
   ```

## Run it

```bash
python -m lead_generation.run_lead_discovery
```

This runs the example (Germany / Automotive / Industrial sensors / End users
only) and writes results to `data/leads.csv`.

## Using it in your own code

Search criteria are now bundled into a `LeadDiscoveryRequest` object, and
results come back as a list of `Lead` objects (instead of plain dicts):

```python
from dotenv import load_dotenv
from lead_generation.lead_discovery import LeadDiscoveryAgent, LeadDiscoveryRequest

load_dotenv()

agent = LeadDiscoveryAgent()

request = LeadDiscoveryRequest(
    region="Germany",
    industry="Automotive",
    lead_count=10,
    product_category="Industrial sensors",
    target_type="End users only",
)

leads = agent.discover(request)          # note: discover(), not discover_leads(...)
agent.save_to_csv(leads, output_path="data/leads.csv")
```

## Output format (`data/leads.csv`)

| Column        | Description                                   |
|---------------|------------------------------------------------|
| company_name  | Best guess at company name (from page title)  |
| website       | Full normalized website URL, e.g. `https://example.com` |
| country       | The region passed in (e.g. "Germany")         |
| source_url    | Exact URL the lead was found at               |
| search_query  | Which search query produced this result       |
| notes         | Short content snippet, for manual review      |

## Known limitations (by design, for Sprint 1)

- No automatic filtering of distributors/traders vs. true end users -
  query wording nudges toward end users (assembly plants, production
  facilities, "factories using industrial sensors", etc.), but results
  should still be spot-checked using the `notes` column.
- No email/contact extraction yet (planned for a later sprint).
- No CRM integration or lead scoring yet.
- Dedup is by website domain only.

## Next sprint ideas

- Contact/email discovery per lead
- Lead scoring (e.g. likelihood of being a true end user)
- CRM push (HubSpot/Salesforce)
- Simple UI/dashboard for reviewing leads
